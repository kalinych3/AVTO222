﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Avto
{
    public partial class Spravochnick_Model : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        private readonly User _user;
        public Spravochnick_Model(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateColums()
        {
            dataGridViewOmodel.Columns.Add("ID", "№");
            dataGridViewOmodel.Columns.Add("Nazvanie", "Название");
            dataGridViewOmodel.Columns.Add("Opisanie", "Описание");
           
        }
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2));
        }
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Spravochnick_Model";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }

        private void Spravochnick_Model_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridViewOmodel);
        }

        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void КомплектацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Komplektacia n = new Komplektacia(_user);
            this.Hide();
            n.ShowDialog();
        }

        private void базоваяКомплектацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bazovaya_Kom d = new Bazovaya_Kom(_user);
            this.Hide();
            d.ShowDialog();
        }

        private void опцииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Opcii a = new Opcii(_user);
            this.Hide();
            a.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }

        private void dataGridViewOmodel_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewOmodel.Rows[selectedRow];

                ID_textBox.Text = row.Cells[0].Value.ToString();
                model_textBox.Text = row.Cells[1].Value.ToString();
                opicanie_textBox.Text = row.Cells[2].Value.ToString();
              
            }
        }
    }
}
