﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    public partial class Avtorizacia : Form
    {
      DataBase dataBase = new DataBase();
        
        private readonly User _user;
        public Avtorizacia(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        public Avtorizacia()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Avtorizacia_Load(object sender, EventArgs e)
        {
            
        }
        private void Vhod_Click(object sender, EventArgs e)
        {
            var login = Login.Text;
            var parol = Parol.Text;
            
            SqlDataAdapter adapter = new SqlDataAdapter(); 
            DataTable table = new DataTable();

            string querystring = $"select ID, Polzevatel_Imya, Parol, ID_Role from Polzevatel where Polzevatel_Imya = '{login}' and Parol = '{parol}' ";

            SqlCommand command = new SqlCommand(querystring, dataBase.getConnection());
           
            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (Login.Text == String.Empty || Parol.Text == String.Empty)
            {
                MessageBox.Show("Пустые поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (table.Rows.Count == 1) 
            {
                var user = new User(table.Rows[0].ItemArray[1].ToString(), Convert.ToBoolean(table.Rows[0].ItemArray[3]),Convert.ToBoolean(table.Rows[0].ItemArray[3]));

                MessageBox.Show("Добро пожаловать!","Успешно!",MessageBoxButtons.OK, MessageBoxIcon.Information);
                Menu menu = new Menu(user);
                this.Hide();
                menu.ShowDialog();
            }
            else
                MessageBox.Show("Такого аккаунта не существует!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }
      
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e) {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();
            
            aboba.ShowDialog();
        }

        private void Parol_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}

