﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    //Сопоставления типов данных SQL Server!!!!
    public partial class Dogovor : Form
    {
        DataBase dataBase = new DataBase();
        private readonly User _user;
        int selectedRow;

        public Dogovor(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void CreateColums()
        {
            dataGridView_Dogovor.Columns.Add("ID", "№");
            dataGridView_Dogovor.Columns.Add("ID_Klient", "Клиент");
            dataGridView_Dogovor.Columns.Add("ID_Rabotnick", "Работник");
            dataGridView_Dogovor.Columns.Add("ID_Filial", "Филиал");
            dataGridView_Dogovor.Columns.Add("ID_Komplektacia", "Комплектация");
            dataGridView_Dogovor.Columns.Add("Stoimost", "Cтоимость");
            dataGridView_Dogovor.Columns.Add("Data_Zaklycheniya", "Дата");


        }

        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3),record.GetString(4), record.GetDecimal(5), record.GetString(6));
        }
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select Klient.ID_Klient, Rabotnick.ID_Rabotnick, Filial.ID_Filial, Komplektacia.ID_Komplektacia, Dogovor.Stoimost, Data_Data_Zaklycheniya" +
                $" from Dogovor, Filial, Rabotnick, Klient, Komplektacia where Rabotnick.ID = Dogovor.ID  ";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            CreateColums();

            RefreshDataGrid(dataGridView_Dogovor);


        }

        private void button8_Click(object sender, EventArgs e)
        {
           
        }
      

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

      
        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
       

        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();
            aboba.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }
    }
}
