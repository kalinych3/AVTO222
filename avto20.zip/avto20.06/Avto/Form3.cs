﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//using Microsoft.Office.Interop.Excel;

namespace Avto
{
    public partial class Klient_Form : Form
    {
        DataBase dataBase = new DataBase();

        int selectedRow;
        private readonly User _user;
        public Klient_Form(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateColums()
        {
            dataGridViewklient.Columns.Add("ID", "№");
            dataGridViewklient.Columns.Add("Familiya", "Фамилия");
            dataGridViewklient.Columns.Add("Imya", "Имя");
            dataGridViewklient.Columns.Add("Dom", "Отчество");
            dataGridViewklient.Columns.Add("Telefon", "Телефон");
            dataGridViewklient.Columns.Add("Pasport", "Паспорт");


        }
        private void dataGridViewklient_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewklient.Rows[selectedRow];

                ID_textBox.Text = row.Cells[0].Value.ToString();
                Familiya_textBox.Text = row.Cells[1].Value.ToString();
                Imya_textBox.Text = row.Cells[2].Value.ToString();
                Otchestvo_textBox.Text = row.Cells[3].Value.ToString();
                Telefon_textBox.Text = row.Cells[4].Value.ToString();
                Pasport_textBox.Text = row.Cells[5].Value.ToString();
            }
          
        }
        private void ReadSingleRow(DataGridView dgwklient, IDataRecord record)
        {
            dgwklient.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetInt32(4), record.GetString(5));
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridViewklient);


        }
        private void deleteRow()
        {
            int index = dataGridViewklient.CurrentCell.RowIndex;
            dataGridViewklient.Rows[index].Visible = false;
            if (dataGridViewklient.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {

                dataGridViewklient.Rows[index].Cells[5].Value = RowState.Deleted;
                return;
            }
            dataGridViewklient.Rows[index].Cells[5].Value = RowState.Deleted;
        }
        private void Update()
        {
            dataBase.openConnection();
            for (int index = 0; index < dataGridViewklient.Rows.Count; index++)
            {
                var rowState = (RowState)dataGridViewklient.Rows[index].Cells[5].Value;

                if (rowState == RowState.Existed)
                    continue;

                if (rowState == RowState.Deleted)
                {
                    var id = Convert.ToInt32(dataGridViewklient.Rows[index].Cells[0].Value);
                    var deleteQuery = $"delete from Klient where ID = {id}";
                    var command = new SqlCommand(deleteQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
                if (rowState == RowState.Modifiled)
                {
                    var ID = dataGridViewklient.Rows[index].Cells[0].Value.ToString();
                    var Familiya = dataGridViewklient.Rows[index].Cells[1].Value.ToString();
                    var Imya = dataGridViewklient.Rows[index].Cells[2].Value.ToString();
                    var Otchestvo = dataGridViewklient.Rows[index].Cells[3].Value.ToString();
                    var telefon = dataGridViewklient.Rows[index].Cells[4].Value.ToString();
                    var Pasport = dataGridViewklient.Rows[index].Cells[5].Value.ToString();
                    var changeQuery = $"update Klient set Familiya = '{Familiya}', Imya = '{Imya}', Otchestvo = '{Otchestvo}', Telefon = '{telefon}', Pasport ='{Pasport}' where  ID = '{ID}'";

                    var command = new SqlCommand(changeQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
            }
            dataBase.closeConnection();
        }

        private void edit()
        {
            var selectedRowIndex = dataGridViewklient.CurrentCell.RowIndex;

            var id = ID_textBox.Text;

            var Familiya = Familiya_textBox.Text;
            var Imya = Imya_textBox.Text;
            var Otchestvo = Otchestvo_textBox.Text;
            var Pasport = Pasport_textBox.Text;

            int telefon;


            if (dataGridViewklient.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            {
                if (int.TryParse(Telefon_textBox.Text, out telefon))
                {
                    dataGridViewklient.Rows[selectedRowIndex].SetValues(id, Familiya, Imya, Otchestvo, telefon, Pasport);
                    
                }
                else
                {
                    MessageBox.Show("Цена должна иметь числовой формат!");
                }

            }
        }
        private void СlearFields()
        {
            ID_textBox.Text = " ";
            Familiya_textBox.Text = " ";
            Imya_textBox.Text = " ";
            Otchestvo_textBox.Text = " ";
            Telefon_textBox.Text = " ";
            Pasport_textBox.Text = " ";    
        }
        private void RefreshDataGrid(DataGridView dgwklient)
        {
            dgwklient.Rows.Clear();

            string queryString = $"select * from Klient";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgwklient, reader);
            }
            reader.Close();
        }

      

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
       

        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }

      

 
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void update_button_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewklient);
            СlearFields();
        }
        private void search(DataGridView dgwklient)
        {
            dgwklient.Rows.Clear();
            string searchString = $"select * from Filial where concat (ID, Familiya, Imya, Otchestvo, Telefon, Pasport ) like '%" + search_textBox.Text + "%'";
            SqlCommand com = new SqlCommand(searchString, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgwklient, reader);
            }
            reader.Close();
        }
        private void search_textBox_TextChanged(object sender, EventArgs e)
        {
            search(dataGridViewklient);
        }


        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void Add_button_Click_1(object sender, EventArgs e)
        {

            Klient_Dobavit aboba = new Klient_Dobavit();
            aboba.ShowDialog();
        }

        private void Delete_button_Click_1(object sender, EventArgs e)
        {
            deleteRow();
            СlearFields();
            Update();
           
        }

        private void edit_button_Click_1(object sender, EventArgs e)
        {
            edit();
            СlearFields();
            Update();
           
        }

        private void Clear_button_Click_1(object sender, EventArgs e)
        {
            СlearFields();
        }

        private void менюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }
    }
}
