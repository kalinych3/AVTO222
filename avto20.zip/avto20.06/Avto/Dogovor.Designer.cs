﻿
namespace Avto
{
    partial class Dogovor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dogovor));
            this.dataGridView_Dogovor = new System.Windows.Forms.DataGridView();
            this.dogovorBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dogovorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox_Filial = new System.Windows.Forms.ComboBox();
            this.felialBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox_cena = new System.Windows.Forms.TextBox();
            this.comboBox_Komplektacia = new System.Windows.Forms.ComboBox();
            this.rabotnickBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox_Rabotnick = new System.Windows.Forms.ComboBox();
            this.klientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox_Klient = new System.Windows.Forms.ComboBox();
            this.avtoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.search_textBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.печатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выгрузкаВExecelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.менюToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Data = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Dobavit_button = new System.Windows.Forms.Button();
            this.clear_button = new System.Windows.Forms.Button();
            this.delete_button = new System.Windows.Forms.Button();
            this.edit_button = new System.Windows.Forms.Button();
            this.button_obnovit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Dogovor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogovorBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogovorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.felialBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnickBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avtoBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView_Dogovor
            // 
            this.dataGridView_Dogovor.AllowUserToAddRows = false;
            this.dataGridView_Dogovor.AllowUserToDeleteRows = false;
            this.dataGridView_Dogovor.BackgroundColor = System.Drawing.Color.DimGray;
            this.dataGridView_Dogovor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Dogovor.Location = new System.Drawing.Point(0, 110);
            this.dataGridView_Dogovor.Name = "dataGridView_Dogovor";
            this.dataGridView_Dogovor.ReadOnly = true;
            this.dataGridView_Dogovor.Size = new System.Drawing.Size(927, 256);
            this.dataGridView_Dogovor.TabIndex = 0;
            this.dataGridView_Dogovor.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dogovorBindingSource1
            // 
            this.dogovorBindingSource1.DataMember = "Dogovor";
            // 
            // dogovorBindingSource
            // 
            this.dogovorBindingSource.DataMember = "Dogovor";
            // 
            // comboBox_Filial
            // 
            this.comboBox_Filial.DataSource = this.felialBindingSource;
            this.comboBox_Filial.DisplayMember = "Gorod";
            this.comboBox_Filial.FormattingEnabled = true;
            this.comboBox_Filial.Location = new System.Drawing.Point(171, 147);
            this.comboBox_Filial.Name = "comboBox_Filial";
            this.comboBox_Filial.Size = new System.Drawing.Size(135, 21);
            this.comboBox_Filial.TabIndex = 41;
            this.comboBox_Filial.ValueMember = "ID";
            // 
            // felialBindingSource
            // 
            this.felialBindingSource.DataMember = "Felial";
            // 
            // textBox_cena
            // 
            this.textBox_cena.Location = new System.Drawing.Point(438, 33);
            this.textBox_cena.Name = "textBox_cena";
            this.textBox_cena.Size = new System.Drawing.Size(135, 20);
            this.textBox_cena.TabIndex = 34;
            this.textBox_cena.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // comboBox_Komplektacia
            // 
            this.comboBox_Komplektacia.DataSource = this.rabotnickBindingSource;
            this.comboBox_Komplektacia.DisplayMember = "Familiya";
            this.comboBox_Komplektacia.FormattingEnabled = true;
            this.comboBox_Komplektacia.Location = new System.Drawing.Point(171, 186);
            this.comboBox_Komplektacia.Name = "comboBox_Komplektacia";
            this.comboBox_Komplektacia.Size = new System.Drawing.Size(135, 21);
            this.comboBox_Komplektacia.TabIndex = 36;
            this.comboBox_Komplektacia.ValueMember = "ID";
            // 
            // rabotnickBindingSource
            // 
            this.rabotnickBindingSource.DataMember = "Rabotnick";
            // 
            // comboBox_Rabotnick
            // 
            this.comboBox_Rabotnick.DataSource = this.klientBindingSource;
            this.comboBox_Rabotnick.DisplayMember = "Fmiliya";
            this.comboBox_Rabotnick.FormattingEnabled = true;
            this.comboBox_Rabotnick.Location = new System.Drawing.Point(171, 106);
            this.comboBox_Rabotnick.Name = "comboBox_Rabotnick";
            this.comboBox_Rabotnick.Size = new System.Drawing.Size(135, 21);
            this.comboBox_Rabotnick.TabIndex = 35;
            this.comboBox_Rabotnick.ValueMember = "ID";
            this.comboBox_Rabotnick.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // klientBindingSource
            // 
            this.klientBindingSource.DataMember = "Klient";
            // 
            // comboBox_Klient
            // 
            this.comboBox_Klient.DataSource = this.avtoBindingSource;
            this.comboBox_Klient.DisplayMember = "Model";
            this.comboBox_Klient.FormattingEnabled = true;
            this.comboBox_Klient.Location = new System.Drawing.Point(171, 68);
            this.comboBox_Klient.Name = "comboBox_Klient";
            this.comboBox_Klient.Size = new System.Drawing.Size(135, 21);
            this.comboBox_Klient.TabIndex = 34;
            this.comboBox_Klient.ValueMember = "ID";
            this.comboBox_Klient.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // avtoBindingSource
            // 
            this.avtoBindingSource.DataMember = "Avto";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.search_textBox);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.menuStrip1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(927, 113);
            this.panel2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(7, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 33);
            this.label1.TabIndex = 66;
            this.label1.Text = "Страница:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(162, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 37);
            this.label6.TabIndex = 65;
            this.label6.Text = "Договор";
            // 
            // search_textBox
            // 
            this.search_textBox.Location = new System.Drawing.Point(780, 84);
            this.search_textBox.Name = "search_textBox";
            this.search_textBox.Size = new System.Drawing.Size(135, 20);
            this.search_textBox.TabIndex = 63;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Teal;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(714, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 20);
            this.label7.TabIndex = 64;
            this.label7.Text = "Поиск";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.Green;
            this.label10.Location = new System.Drawing.Point(764, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 33);
            this.label10.TabIndex = 61;
            this.label10.Text = "Авто";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(844, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 37);
            this.label11.TabIndex = 62;
            this.label11.Text = "Хит";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.менюToolStripMenuItem,
            this.справочникToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(927, 24);
            this.menuStrip1.TabIndex = 55;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.печатьToolStripMenuItem,
            this.выгрузкаВExecelToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // печатьToolStripMenuItem
            // 
            this.печатьToolStripMenuItem.Name = "печатьToolStripMenuItem";
            this.печатьToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.печатьToolStripMenuItem.Text = "Печать";
            // 
            // выгрузкаВExecelToolStripMenuItem
            // 
            this.выгрузкаВExecelToolStripMenuItem.Name = "выгрузкаВExecelToolStripMenuItem";
            this.выгрузкаВExecelToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.выгрузкаВExecelToolStripMenuItem.Text = "Выгрузка в Excel";
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem1});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            this.менюToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.менюToolStripMenuItem.Text = "Меню";
            // 
            // менюToolStripMenuItem1
            // 
            this.менюToolStripMenuItem1.Name = "менюToolStripMenuItem1";
            this.менюToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.менюToolStripMenuItem1.Text = "Меню";
            this.менюToolStripMenuItem1.Click += new System.EventHandler(this.менюToolStripMenuItem1_Click);
            // 
            // справочникToolStripMenuItem
            // 
            this.справочникToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справочникToolStripMenuItem.Name = "справочникToolStripMenuItem";
            this.справочникToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.справочникToolStripMenuItem.Text = "Справочник";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 361);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(927, 258);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.comboBox_Klient);
            this.panel4.Controls.Add(this.id);
            this.panel4.Controls.Add(this.comboBox_Rabotnick);
            this.panel4.Controls.Add(this.comboBox_Filial);
            this.panel4.Controls.Add(this.comboBox_Komplektacia);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.textBox_cena);
            this.panel4.Controls.Add(this.Data);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Location = new System.Drawing.Point(13, 32);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(583, 214);
            this.panel4.TabIndex = 47;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Teal;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(8, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 25);
            this.label5.TabIndex = 64;
            this.label5.Text = "Комплектация";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Teal;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(8, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 25);
            this.label4.TabIndex = 63;
            this.label4.Text = "Филиал";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Teal;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(8, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 25);
            this.label3.TabIndex = 62;
            this.label3.Text = "Работник";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(8, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 25);
            this.label2.TabIndex = 61;
            this.label2.Text = "Клиент";
            // 
            // id
            // 
            this.id.HideSelection = false;
            this.id.Location = new System.Drawing.Point(171, 33);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(135, 20);
            this.id.TabIndex = 60;
            this.id.UseSystemPasswordChar = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Teal;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(312, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 25);
            this.label15.TabIndex = 58;
            this.label15.Text = "Стоимость";
            // 
            // Data
            // 
            this.Data.Location = new System.Drawing.Point(438, 70);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(135, 20);
            this.Data.TabIndex = 59;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Teal;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(312, 68);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 25);
            this.label16.TabIndex = 57;
            this.label16.Text = "Дата ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Teal;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(9, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 20);
            this.label13.TabIndex = 53;
            this.label13.Text = "ID:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(9, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 31);
            this.label8.TabIndex = 40;
            this.label8.Text = "Запись:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(602, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(322, 31);
            this.label9.TabIndex = 45;
            this.label9.Text = "Управление записями:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.button_obnovit);
            this.panel5.Controls.Add(this.Dobavit_button);
            this.panel5.Controls.Add(this.clear_button);
            this.panel5.Controls.Add(this.delete_button);
            this.panel5.Controls.Add(this.edit_button);
            this.panel5.Location = new System.Drawing.Point(701, 32);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(145, 214);
            this.panel5.TabIndex = 46;
            // 
            // Dobavit_button
            // 
            this.Dobavit_button.BackColor = System.Drawing.Color.Teal;
            this.Dobavit_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Dobavit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Dobavit_button.ForeColor = System.Drawing.Color.Black;
            this.Dobavit_button.Location = new System.Drawing.Point(17, 3);
            this.Dobavit_button.Name = "Dobavit_button";
            this.Dobavit_button.Size = new System.Drawing.Size(111, 37);
            this.Dobavit_button.TabIndex = 48;
            this.Dobavit_button.Text = "Добавить";
            this.Dobavit_button.UseVisualStyleBackColor = false;
            // 
            // clear_button
            // 
            this.clear_button.BackColor = System.Drawing.Color.Teal;
            this.clear_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clear_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clear_button.ForeColor = System.Drawing.Color.Black;
            this.clear_button.Location = new System.Drawing.Point(17, 129);
            this.clear_button.Name = "clear_button";
            this.clear_button.Size = new System.Drawing.Size(111, 37);
            this.clear_button.TabIndex = 21;
            this.clear_button.Text = "Очистить";
            this.clear_button.UseVisualStyleBackColor = false;
            // 
            // delete_button
            // 
            this.delete_button.BackColor = System.Drawing.Color.Teal;
            this.delete_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delete_button.ForeColor = System.Drawing.Color.Black;
            this.delete_button.Location = new System.Drawing.Point(17, 46);
            this.delete_button.Name = "delete_button";
            this.delete_button.Size = new System.Drawing.Size(111, 37);
            this.delete_button.TabIndex = 8;
            this.delete_button.Text = "Удалить";
            this.delete_button.UseVisualStyleBackColor = false;
            // 
            // edit_button
            // 
            this.edit_button.BackColor = System.Drawing.Color.Teal;
            this.edit_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.edit_button.ForeColor = System.Drawing.Color.Black;
            this.edit_button.Location = new System.Drawing.Point(17, 89);
            this.edit_button.Name = "edit_button";
            this.edit_button.Size = new System.Drawing.Size(111, 37);
            this.edit_button.TabIndex = 9;
            this.edit_button.Text = "Изменить";
            this.edit_button.UseVisualStyleBackColor = false;
            // 
            // button_obnovit
            // 
            this.button_obnovit.BackColor = System.Drawing.Color.Teal;
            this.button_obnovit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_obnovit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_obnovit.ForeColor = System.Drawing.Color.Black;
            this.button_obnovit.Location = new System.Drawing.Point(17, 172);
            this.button_obnovit.Name = "button_obnovit";
            this.button_obnovit.Size = new System.Drawing.Size(111, 37);
            this.button_obnovit.TabIndex = 49;
            this.button_obnovit.Text = "Обновить";
            this.button_obnovit.UseVisualStyleBackColor = false;
            // 
            // Dogovor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(927, 619);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.dataGridView_Dogovor);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Dogovor";
            this.Text = "Договор\"АвтоХит\"";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Dogovor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogovorBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogovorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.felialBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnickBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avtoBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_Dogovor;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox_Klient;
        private System.Windows.Forms.ComboBox comboBox_Komplektacia;
        private System.Windows.Forms.ComboBox comboBox_Rabotnick;
        private System.Windows.Forms.TextBox textBox_cena;
     
        private System.Windows.Forms.BindingSource avtoBindingSource;
       
        private System.Windows.Forms.BindingSource klientBindingSource;
      
        private System.Windows.Forms.BindingSource rabotnickBindingSource;
        private System.Windows.Forms.ComboBox comboBox_Filial;
       
        private System.Windows.Forms.BindingSource dogovorBindingSource;
       
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDAvtoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDKlientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDRabotnickDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDFelialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataZakazaDataGridViewTextBoxColumn;
        
        private System.Windows.Forms.BindingSource felialBindingSource;
        
    
        private System.Windows.Forms.BindingSource dogovorBindingSource1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Data;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Dobavit_button;
        private System.Windows.Forms.Button clear_button;
        private System.Windows.Forms.Button delete_button;
        private System.Windows.Forms.Button edit_button;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem печатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выгрузкаВExecelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem справочникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox search_textBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_obnovit;
    }
}