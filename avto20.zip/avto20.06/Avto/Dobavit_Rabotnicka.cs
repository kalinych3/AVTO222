﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Avto
{
    public partial class Dobavit_Rabotnicka : Form
    {
        DataBase dataBase = new DataBase();
        private readonly User _user;
        public Dobavit_Rabotnicka(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateColums()
        { 
            dataGridViewDobavit.Columns.Add("ID", "№"); 
            dataGridViewDobavit.Columns.Add("ID_Role", "Роль");
            dataGridViewDobavit.Columns.Add("Familiya", "Фамилия");
            dataGridViewDobavit.Columns.Add("Imya", "Имя");
            dataGridViewDobavit.Columns.Add("Otchestvo", "Отчество");
            dataGridViewDobavit.Columns.Add("Telefon", "Телефон");
            var checkColumn = new DataGridViewCheckBoxColumn();
            checkColumn.HeaderText = "Aдмин";
            dataGridViewDobavit.Columns.Add(checkColumn);
            var checkColumn2 = new DataGridViewCheckBoxColumn();
            checkColumn2.HeaderText = "Менеджер";
            dataGridViewDobavit.Columns.Add(checkColumn2);
            dataGridViewDobavit.Columns.Add("Polzevatel_Imya", "Логин");
            dataGridViewDobavit.Columns.Add("Parol", "Пароль");
          
        }

        private void ReadSingleRow(DataGridView dgwklient, IDataRecord record)
        {
            dgwklient.Rows.Add(record.GetInt32(0), record.GetInt32(1), record.GetString(2), record.GetString(3), record.GetString(4), record.GetInt32(5), record.GetString(6), record.GetString(7), record.GetString(8), record.GetInt32(9));
        }
       
        private void panel3_Paint(object sender, PaintEventArgs e)

        {

        }
        private void RefreshDataGrid(DataGridView dgwDobavit)//обновление
        {
            dgwDobavit.Rows.Clear();

            string queryString = $"select Rabotncik.ID, Rabotncik.Familiya, Rabotncik.Imya, Rabotncik.Otchestvo, Rabotncik.Telefon, Role.Nazvanie,Polzevatel.Polzevatel_Imya, Polzevatel.Parol from Rabotnick,Polzevatel,Role where Rabotnick.ID = ID_Role.ID";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgwDobavit, reader);
            }

            reader.Close();
        }
        private void Registracia_Load(object sender, EventArgs e)
        {
        

            CreateColums();
            RefreshDataGrid(dataGridViewDobavit);
        }

        private void Registracia_button_Click(object sender, EventArgs e)
        {
            var login = Login.Text;
            var parol = Parol.Text;
            var familiya = Familiya_textBox;
            var imya = Imya_textBox;
            var Otchestvo = Otchestvo_textBox;
            var Telefon = Telefon_textBox;



            if (checkpolzevatel())
            {
                return;
            }

            string querystring = $"insert into Polzevatel, Role, Dobavit (Polzevatel_Imya, Parol, IsAdmin, IsMenedger, Familiya, Imya, Otchestvo ,Telefon) values ('{login}', '{parol}', 0 , 0 ,'{familiya}', '{imya}' , '{Otchestvo}' , '{Telefon}')";

            SqlCommand command = new SqlCommand(querystring, dataBase.getConnection());

            dataBase.openConnection();

            if (Login.Text == String.Empty || Parol.Text == String.Empty)
            {
                MessageBox.Show("Пустые поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
           

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Аккаунт успешно создан!", "Успешно!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Rabotnick_Form rabotnick = new Rabotnick_Form(_user);
                this.Hide();
                rabotnick.ShowDialog();

            }
            else
            {
                MessageBox.Show("Аккаунт не создан!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            dataBase.closeConnection();
            RefreshDataGrid(dataGridViewDobavit);

        }
        private Boolean checkpolzevatel()
        {
            var login = Login.Text;
            var parol = Parol.Text;
            var familiya = Familiya_textBox;
            var imya = Imya_textBox;
            var Otchestvo = Otchestvo_textBox;
            var Telefon = Telefon_textBox;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            string querystring = $"select ID, Polzevatel_Imya, Parol, Familiya ,Imya, Otchestvo ,Telefon from Polzevatel where Polzevatel_Imya = '{login}' , Parol = '{parol}',Familiya ='{familiya}' , Imya ='{imya}', Otchestvo ='{Otchestvo}'and Telefon='{Telefon}'";

            SqlCommand command = new SqlCommand(querystring, dataBase.getConnection());
            
            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0) 
            {
                MessageBox.Show("Пользователь уже существует!", "Ошибка!" ,MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return true;
            }
            else 
            {
                
                return false;
            }
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            Menu Avtorizacia = new Menu (_user);
            this.Hide();
            Avtorizacia.ShowDialog();
        }
    }
}
