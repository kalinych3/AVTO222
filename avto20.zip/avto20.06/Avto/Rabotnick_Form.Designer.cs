﻿
namespace Avto
{
    partial class Rabotnick_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rabotnick_Form));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Parol = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Login = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Role_comboBox = new System.Windows.Forms.ComboBox();
            this.roleBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.avto2585858DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Telefon_textBox = new System.Windows.Forms.TextBox();
            this.ID_textBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Otchestvo_textBox = new System.Windows.Forms.TextBox();
            this.Imya_textBox = new System.Windows.Forms.TextBox();
            this.Familiya_textBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Obnovit = new System.Windows.Forms.Button();
            this.Registracia_button = new System.Windows.Forms.Button();
            this.clear_button = new System.Windows.Forms.Button();
            this.delete_button = new System.Windows.Forms.Button();
            this.edit_button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.roleBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.roleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.search_textBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.печатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выгрузкаВExecelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.менюToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridViewRabotnick = new System.Windows.Forms.DataGridView();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.rabotnickBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.rabotnickBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avto2585858DataSetBindingSource)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRabotnick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnickBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnickBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 358);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(901, 282);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.Parol);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.Login);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.Role_comboBox);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.Telefon_textBox);
            this.panel4.Controls.Add(this.ID_textBox);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.Otchestvo_textBox);
            this.panel4.Controls.Add(this.Imya_textBox);
            this.panel4.Controls.Add(this.Familiya_textBox);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(21, 41);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(537, 229);
            this.panel4.TabIndex = 47;
            // 
            // Parol
            // 
            this.Parol.HideSelection = false;
            this.Parol.Location = new System.Drawing.Point(377, 60);
            this.Parol.Name = "Parol";
            this.Parol.Size = new System.Drawing.Size(135, 20);
            this.Parol.TabIndex = 60;
            this.Parol.UseSystemPasswordChar = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Teal;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(276, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 25);
            this.label15.TabIndex = 58;
            this.label15.Text = "Пароль";
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(377, 29);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(135, 20);
            this.Login.TabIndex = 59;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Teal;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(276, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 25);
            this.label16.TabIndex = 57;
            this.label16.Text = "Логин";
            // 
            // Role_comboBox
            // 
            this.Role_comboBox.FormattingEnabled = true;
            this.Role_comboBox.Location = new System.Drawing.Point(114, 182);
            this.Role_comboBox.Name = "Role_comboBox";
            this.Role_comboBox.Size = new System.Drawing.Size(135, 21);
            this.Role_comboBox.TabIndex = 56;
            this.Role_comboBox.SelectedIndexChanged += new System.EventHandler(this.Role_comboBox_SelectedIndexChanged);
            // 
            // roleBindingSource2
            // 
            this.roleBindingSource2.DataMember = "Role";
            this.roleBindingSource2.DataSource = this.avto2585858DataSetBindingSource;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Teal;
            this.label14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(17, 180);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 20);
            this.label14.TabIndex = 55;
            this.label14.Text = "Роль:";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Teal;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(17, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 20);
            this.label13.TabIndex = 53;
            this.label13.Text = "ID:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Teal;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(17, 154);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 20);
            this.label12.TabIndex = 52;
            this.label12.Text = "Телефон:";
            // 
            // Telefon_textBox
            // 
            this.Telefon_textBox.Location = new System.Drawing.Point(114, 156);
            this.Telefon_textBox.Name = "Telefon_textBox";
            this.Telefon_textBox.Size = new System.Drawing.Size(135, 20);
            this.Telefon_textBox.TabIndex = 51;
            // 
            // ID_textBox
            // 
            this.ID_textBox.Location = new System.Drawing.Point(114, 29);
            this.ID_textBox.Name = "ID_textBox";
            this.ID_textBox.Size = new System.Drawing.Size(135, 20);
            this.ID_textBox.TabIndex = 50;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Teal;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(17, 125);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 20);
            this.label11.TabIndex = 49;
            this.label11.Text = "Отчество:";
            // 
            // Otchestvo_textBox
            // 
            this.Otchestvo_textBox.Location = new System.Drawing.Point(114, 125);
            this.Otchestvo_textBox.Name = "Otchestvo_textBox";
            this.Otchestvo_textBox.Size = new System.Drawing.Size(135, 20);
            this.Otchestvo_textBox.TabIndex = 46;
            // 
            // Imya_textBox
            // 
            this.Imya_textBox.Location = new System.Drawing.Point(114, 96);
            this.Imya_textBox.Name = "Imya_textBox";
            this.Imya_textBox.Size = new System.Drawing.Size(135, 20);
            this.Imya_textBox.TabIndex = 45;
            this.Imya_textBox.TextChanged += new System.EventHandler(this.Imya_textBox_TextChanged);
            // 
            // Familiya_textBox
            // 
            this.Familiya_textBox.Location = new System.Drawing.Point(114, 65);
            this.Familiya_textBox.Name = "Familiya_textBox";
            this.Familiya_textBox.Size = new System.Drawing.Size(135, 20);
            this.Familiya_textBox.TabIndex = 44;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Teal;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(17, 94);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 20);
            this.label10.TabIndex = 43;
            this.label10.Text = "Имя:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(27, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(17, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 20);
            this.label2.TabIndex = 41;
            this.label2.Text = "Фамилия:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(569, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(322, 31);
            this.label6.TabIndex = 45;
            this.label6.Text = "Управление записями:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.button_Obnovit);
            this.panel3.Controls.Add(this.Registracia_button);
            this.panel3.Controls.Add(this.clear_button);
            this.panel3.Controls.Add(this.delete_button);
            this.panel3.Controls.Add(this.edit_button);
            this.panel3.Location = new System.Drawing.Point(675, 41);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(145, 229);
            this.panel3.TabIndex = 46;
            // 
            // button_Obnovit
            // 
            this.button_Obnovit.BackColor = System.Drawing.Color.Teal;
            this.button_Obnovit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_Obnovit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Obnovit.ForeColor = System.Drawing.Color.Black;
            this.button_Obnovit.Location = new System.Drawing.Point(17, 182);
            this.button_Obnovit.Name = "button_Obnovit";
            this.button_Obnovit.Size = new System.Drawing.Size(111, 37);
            this.button_Obnovit.TabIndex = 49;
            this.button_Obnovit.Text = "Обновить";
            this.button_Obnovit.UseVisualStyleBackColor = false;
            // 
            // Registracia_button
            // 
            this.Registracia_button.BackColor = System.Drawing.Color.Teal;
            this.Registracia_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Registracia_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Registracia_button.ForeColor = System.Drawing.Color.Black;
            this.Registracia_button.Location = new System.Drawing.Point(17, 10);
            this.Registracia_button.Name = "Registracia_button";
            this.Registracia_button.Size = new System.Drawing.Size(111, 37);
            this.Registracia_button.TabIndex = 48;
            this.Registracia_button.Text = "Добавить";
            this.Registracia_button.UseVisualStyleBackColor = false;
            this.Registracia_button.Click += new System.EventHandler(this.Registracia_button_Click);
            // 
            // clear_button
            // 
            this.clear_button.BackColor = System.Drawing.Color.Teal;
            this.clear_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clear_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clear_button.ForeColor = System.Drawing.Color.Black;
            this.clear_button.Location = new System.Drawing.Point(17, 139);
            this.clear_button.Name = "clear_button";
            this.clear_button.Size = new System.Drawing.Size(111, 37);
            this.clear_button.TabIndex = 21;
            this.clear_button.Text = "Очистить";
            this.clear_button.UseVisualStyleBackColor = false;
            this.clear_button.Click += new System.EventHandler(this.clear_button_Click);
            // 
            // delete_button
            // 
            this.delete_button.BackColor = System.Drawing.Color.Teal;
            this.delete_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delete_button.ForeColor = System.Drawing.Color.Black;
            this.delete_button.Location = new System.Drawing.Point(17, 53);
            this.delete_button.Name = "delete_button";
            this.delete_button.Size = new System.Drawing.Size(111, 37);
            this.delete_button.TabIndex = 8;
            this.delete_button.Text = "Удалить";
            this.delete_button.UseVisualStyleBackColor = false;
            this.delete_button.Click += new System.EventHandler(this.delete_button_Click);
            // 
            // edit_button
            // 
            this.edit_button.BackColor = System.Drawing.Color.Teal;
            this.edit_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.edit_button.ForeColor = System.Drawing.Color.Black;
            this.edit_button.Location = new System.Drawing.Point(17, 96);
            this.edit_button.Name = "edit_button";
            this.edit_button.Size = new System.Drawing.Size(111, 37);
            this.edit_button.TabIndex = 9;
            this.edit_button.Text = "Изменить";
            this.edit_button.UseVisualStyleBackColor = false;
            this.edit_button.Click += new System.EventHandler(this.edit_button_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(15, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 31);
            this.label7.TabIndex = 40;
            this.label7.Text = "Запись:";
            // 
            // roleBindingSource1
            // 
            this.roleBindingSource1.DataMember = "Role";
            // 
            // roleBindingSource
            // 
            this.roleBindingSource.DataMember = "Role";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.search_textBox);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.menuStrip1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(901, 102);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(0, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 33);
            this.label5.TabIndex = 60;
            this.label5.Text = "Страница:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(155, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 37);
            this.label4.TabIndex = 59;
            this.label4.Text = "Работник";
            // 
            // search_textBox
            // 
            this.search_textBox.Location = new System.Drawing.Point(754, 78);
            this.search_textBox.Name = "search_textBox";
            this.search_textBox.Size = new System.Drawing.Size(135, 20);
            this.search_textBox.TabIndex = 57;
            this.search_textBox.TextChanged += new System.EventHandler(this.search_textBox_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Teal;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(688, 79);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 20);
            this.label9.TabIndex = 58;
            this.label9.Text = "Поиск";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(738, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 33);
            this.label3.TabIndex = 55;
            this.label3.Text = "Авто";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(818, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 37);
            this.label8.TabIndex = 56;
            this.label8.Text = "Хит";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.менюToolStripMenuItem,
            this.справочникToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(901, 24);
            this.menuStrip1.TabIndex = 54;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.печатьToolStripMenuItem,
            this.выгрузкаВExecelToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // печатьToolStripMenuItem
            // 
            this.печатьToolStripMenuItem.Name = "печатьToolStripMenuItem";
            this.печатьToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.печатьToolStripMenuItem.Text = "Печать";
            // 
            // выгрузкаВExecelToolStripMenuItem
            // 
            this.выгрузкаВExecelToolStripMenuItem.Name = "выгрузкаВExecelToolStripMenuItem";
            this.выгрузкаВExecelToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.выгрузкаВExecelToolStripMenuItem.Text = "Выгрузка в Excel";
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem1});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            this.менюToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.менюToolStripMenuItem.Text = "Меню";
            // 
            // менюToolStripMenuItem1
            // 
            this.менюToolStripMenuItem1.Name = "менюToolStripMenuItem1";
            this.менюToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.менюToolStripMenuItem1.Text = "Меню";
            this.менюToolStripMenuItem1.Click += new System.EventHandler(this.менюToolStripMenuItem1_Click);
            // 
            // справочникToolStripMenuItem
            // 
            this.справочникToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справочникToolStripMenuItem.Name = "справочникToolStripMenuItem";
            this.справочникToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.справочникToolStripMenuItem.Text = "Справочник";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // dataGridViewRabotnick
            // 
            this.dataGridViewRabotnick.AllowUserToAddRows = false;
            this.dataGridViewRabotnick.AllowUserToDeleteRows = false;
            this.dataGridViewRabotnick.BackgroundColor = System.Drawing.Color.DimGray;
            this.dataGridViewRabotnick.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRabotnick.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridViewRabotnick.Location = new System.Drawing.Point(0, 102);
            this.dataGridViewRabotnick.Name = "dataGridViewRabotnick";
            this.dataGridViewRabotnick.ReadOnly = true;
            this.dataGridViewRabotnick.Size = new System.Drawing.Size(901, 259);
            this.dataGridViewRabotnick.TabIndex = 2;
            this.dataGridViewRabotnick.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRabotnick_CellClick);
            // 
            // rabotnickBindingSource1
            // 
            this.rabotnickBindingSource1.DataMember = "Rabotnick";
            // 
            // rabotnickBindingSource
            // 
            this.rabotnickBindingSource.DataMember = "Rabotnick";
            // 
            // Rabotnick_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(901, 640);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridViewRabotnick);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Rabotnick_Form";
            this.Text = "Работник \"АвтоХит\"";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource2)).EndInit();
           
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRabotnick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnickBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnickBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridViewRabotnick;
        
        private System.Windows.Forms.BindingSource rabotnickBindingSource;
       
        private System.Windows.Forms.BindingSource rabotnickBindingSource1;
        
        private System.Windows.Forms.DataGridViewTextBoxColumn iDRabotnickDataGridViewTextBoxColumn;
    
        private System.Windows.Forms.DataGridViewTextBoxColumn familiyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otchestvoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDPolzevatelDataGridViewTextBoxColumn;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem печатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выгрузкаВExecelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem справочникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox search_textBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button clear_button;
        private System.Windows.Forms.Button delete_button;
        private System.Windows.Forms.Button edit_button;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Telefon_textBox;
        private System.Windows.Forms.TextBox ID_textBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Otchestvo_textBox;
        private System.Windows.Forms.TextBox Imya_textBox;
        private System.Windows.Forms.TextBox Familiya_textBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Role_comboBox;
        private Avto11111DataSet avto11111DataSet;
        private System.Windows.Forms.BindingSource roleBindingSource;
        private Avto11111DataSetTableAdapters.RoleTableAdapter roleTableAdapter;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button Registracia_button;
        private System.Windows.Forms.TextBox Parol;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Login;
        private System.Windows.Forms.Label label16;
        
        private System.Windows.Forms.BindingSource roleBindingSource1;
       
        private System.Windows.Forms.Button button_Obnovit;
        private System.Windows.Forms.BindingSource avto2585858DataSetBindingSource;
       
        private System.Windows.Forms.BindingSource roleBindingSource2;
       
    }
}