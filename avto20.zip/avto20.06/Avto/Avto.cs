﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Avto
{
    enum RowState 
    { 
       Existed,
       New,
       Modifiled,
       ModifiedNew,
       Deleted
    }
    public partial class Avto : Form
    {
        DataBase dataBase = new DataBase();

        int selectedRow;

        private readonly User _user;

        public Avto(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateColums()
        {
            dataGridViewAvto.Columns.Add("ID", "№");
            dataGridViewAvto.Columns.Add("Model", "Модель");
            dataGridViewAvto.Columns.Add("Cvet", "Цвет");
            dataGridViewAvto.Columns.Add("cena", "Цена");
           

        }
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetInt32(3));
        }

        private void RefreshDataGrid(DataGridView dgw) 
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Avto";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader(); 
            
            while(reader.Read()) 
            { 
              ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
            
         

        private void Form2_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridViewAvto);

        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
        }

   

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();
            aboba.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }

      
       

       
        private void button8_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewAvto);
            СlearFields();
        }

       

        
        private void print_button_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(dataGridViewAvto.Size.Width + 10, dataGridViewAvto.Size.Height + 10);
            dataGridViewAvto.DrawToBitmap(bmp, dataGridViewAvto.Bounds);
            

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void fileItem_Click(object sender, EventArgs e)
        {

        }

        private void ExcellTooltem_Click(object sender, EventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void StripMenuItem_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void toolStrip_Oprogram_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();
            aboba.ShowDialog();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0) 
            { 
               DataGridViewRow row = dataGridViewAvto.Rows[selectedRow];

                ID_textBox.Text = row.Cells[0].Value.ToString();
                model_textBox.Text = row.Cells[1].Value.ToString();
                Cvet_textBox.Text = row.Cells[2].Value.ToString();
                cena_textBox.Text = row.Cells[3].Value.ToString();
            }
        }
        private void search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Avto where concat (ID, Model, Cvet,cena) like '%" + search_textBox.Text +"%'";
            SqlCommand com = new SqlCommand(searchString, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader  reader = com.ExecuteReader();
            while (reader.Read()) 
            { 
            ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        private void search_textBox_TextChanged(object sender, EventArgs e)
        {
            search(dataGridViewAvto);
            СlearFields();
        }
        private void deleteRow() 
        {
            int index = dataGridViewAvto.CurrentCell.RowIndex;
            dataGridViewAvto.Rows[index].Visible = false;
            if (dataGridViewAvto.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {

                dataGridViewAvto.Rows[index].Cells[3].Value = RowState.Deleted;
                return;
            }
            dataGridViewAvto.Rows[index].Cells[3].Value = RowState.Deleted;
        }
        private void Update() 
        {
            dataBase.openConnection();
            for(int index = 0; index < dataGridViewAvto.Rows.Count; index++) 
            {
                var rowState = (RowState)dataGridViewAvto.Rows[index].Cells[3].Value;

                if (rowState == RowState.Existed)
                    continue;
                
                if(rowState == RowState.Deleted) 
                { 
                var id= Convert.ToInt32(dataGridViewAvto.Rows[index].Cells[0].Value);
                    var deleteQuery = $"delete from Avto where ID = {id}";
                    var command = new SqlCommand(deleteQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
                if(rowState == RowState.Modifiled) 
                {
                    var ID = dataGridViewAvto.Rows[index].Cells[0].Value.ToString();
                    var model = dataGridViewAvto.Rows[index].Cells[1].Value.ToString();
                    var Cvet = dataGridViewAvto.Rows[index].Cells[2].Value.ToString();
                    var cena = dataGridViewAvto.Rows[index].Cells[3].Value.ToString();

                    var changeQuery = $"update Avto set model = '{model}', Cvet = '{Cvet}', cena = '{cena}' where  ID = '{ID}'";

                    var command = new SqlCommand(changeQuery, dataBase.getConnection());   
                    command.ExecuteNonQuery();
                }
            }
            dataBase.closeConnection();
        }
        private void delete_button_Click(object sender, EventArgs e)
        {
            deleteRow();
            СlearFields();
        }

        private void save_button_Click(object sender, EventArgs e)
        {
            Update();
            СlearFields();
        }
        private void edit() 
        {
            var selectedRowIndex = dataGridViewAvto.CurrentCell.RowIndex;

            var id = ID_textBox.Text;
            var model = model_textBox.Text;
            var cvet = Cvet_textBox.Text;
            int cena;


            if (dataGridViewAvto.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            {
                if (int.TryParse(cena_textBox.Text, out cena)) 
                {
                    dataGridViewAvto.Rows[selectedRowIndex].SetValues(id, model, cvet, cena);
                   
                }
                else 
                {
                    MessageBox.Show("Цена должна иметь числовой формат!") ;
                }

            }
        }
        private void edit_button_Click(object sender, EventArgs e)
        {
            edit();
            СlearFields();
        }

        private void ID_textBox_TextChanged(object sender, EventArgs e)
        {

        } 
        private void СlearFields()
        {
            ID_textBox.Text = " ";
            model_textBox.Text = " " ;
            Cvet_textBox.Text = " ";
            cena_textBox.Text = " ";
            
        }
        private void clear_button_Click(object sender, EventArgs e)
        {
            СlearFields();
        }

        private void Add_button_Click(object sender, EventArgs e)
        {
           
            Update();
        }

        private void Delete_button_Click_1(object sender, EventArgs e)
        {
            deleteRow();
            СlearFields();
            Update();
        }

        private void edit_button_Click_1(object sender, EventArgs e)
        {
            edit();
            СlearFields();
            Update();
        }

        private void Clear_button_Click_1(object sender, EventArgs e)
        {
            СlearFields();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }
    }
}