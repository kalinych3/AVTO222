﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    public partial class Komplektacia : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        private readonly User _user;

        public Komplektacia(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateColums() 
        {

            dataGridViewKom.Columns.Add("ID", "№");//0
            dataGridViewKom.Columns.Add("Nazvanie", "Название");//1
            dataGridViewKom.Columns.Add("Tip_kpp", "Тип КПП");//2
            dataGridViewKom.Columns.Add("Moshnost_Dvigatela", "Мощность");//3
            dataGridViewKom.Columns.Add("Obyem_Dvigatelya", "Обьем двигателя");//4
            dataGridViewKom.Columns.Add("Privod", "Привод");//5
            dataGridViewKom.Columns.Add("ID_Avto", "Модель");//6
            dataGridViewKom.Columns.Add("ID_Bazovaya_Komplektacia", "Базовая");//7
            dataGridViewKom.Columns.Add("Kol_Mest", "Кол-мест");//8
            dataGridViewKom.Columns.Add("Kol_Dveri", "Кол-дверей");//9
            dataGridViewKom.Columns.Add("Cena", "Цена");//10
            dataGridViewKom.Columns.Add("ID_Sklad", "Склад");//11
        }
        private void Komplektacia_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridViewKom);
        }
        private void ReadSingleRow(DataGridView dgwR, IDataRecord record)
        {
            dgwR.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetInt32(2), record.GetInt32(3), record.GetInt32(4), record.GetString(5), record.GetInt32(6), record.GetInt32(7), record.GetInt32(8), record.GetInt32(9), record.GetDecimal(10), record.GetInt32(11));
        }
        private void RefreshDataGrid(DataGridView dgwR)
        {
            dgwR.Rows.Clear();

            string queryString = $"select * from Komplektacia";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgwR, reader);
            }
            reader.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();
            aboba.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
           
        }
      
        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }


        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

      

    

       

        private void менюToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void базоваяКомплектацияToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Bazovaya_Kom n = new Bazovaya_Kom(_user);
            this.Hide();
            n.ShowDialog();
        }

        private void опцииToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Opcii u = new Opcii(_user);
            this.Hide();
            u.ShowDialog();
        }

        private void оМоделейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Spravochnick_Model u = new Spravochnick_Model(_user);
            this.Hide();
            u.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }

        private void dataGridViewKom_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                selectedRow = e.RowIndex;

                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridViewKom.Rows[selectedRow];

                    ID_textBox.Text = row.Cells[0].Value.ToString();
                    Nazvanie_textBox.Text = row.Cells[1].Value.ToString();
                    Tip_kpp_textBox.Text = row.Cells[2].Value.ToString();
                    Moshnost_textBox.Text = row.Cells[3].Value.ToString();
                    Kol_dveri_textBox.Text = row.Cells[4].Value.ToString();
                    Kol_mest_textBox.Text = row.Cells[5].Value.ToString();
                    Privod.Text = row.Cells[6].Value.ToString();
                    textBox_Obyem.Text = row.Cells[7].Value.ToString();
                    Cena.Text = row.Cells[8].Value.ToString();
                    Avto_comboBox.Text = row.Cells[9].Value.ToString();
                    Bazov_comboBox.Text = row.Cells[10].Value.ToString();
                    Sklad_comboBox.Text = row.Cells[11].Value.ToString();




                }
            }
        }

        private void Registracia_button_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewKom);
        }
    }
}
            