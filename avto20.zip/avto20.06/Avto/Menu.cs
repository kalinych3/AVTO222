﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Avto
{
    public partial class Menu : Form
    {
        private readonly User _user;
        public Menu(User user)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            _user = user;
        }
        private void Admin() 
        {
            
            

        }
        private void Menu_Load(object sender, EventArgs e)
        {
            User_textBox.Text = $"{_user.Login} :{_user.StatusAd}";
            Admin();
        }
        
        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Komplektacia o = new Komplektacia(_user);
            o.ShowDialog();
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();
            aboba.ShowDialog();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Klient_Form o = new Klient_Form(_user);
            o.ShowDialog();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Rabotnick_Form o = new Rabotnick_Form(_user);
            o.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dogovor o = new Dogovor(_user);
            o.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Avto o = new Avto(_user);
            o.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Filial o = new  Filial(_user);
            o.ShowDialog();
            this.Close();
        }

     


        private void Registracia_button_Click(object sender, EventArgs e)
        {
           
        }

        private void User_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Sklad_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Sklad o = new Sklad(_user);
            o.ShowDialog();
            this.Close();
        }
    }
}
