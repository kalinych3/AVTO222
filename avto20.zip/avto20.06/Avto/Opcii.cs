﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    public partial class Opcii : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        private readonly User _user;


        public Opcii(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
      
        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //Menu o = new Menu();
            //o.ShowDialog();
            //this.Close();
        }

        

        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }


        private void CreateColums()
        {
            dataGridViewOpcii.Columns.Add("ID", "№");
            dataGridViewOpcii.Columns.Add("Nazvanie", "Название");
            dataGridViewOpcii.Columns.Add("Opicanie", "Описание");
            dataGridViewOpcii.Columns.Add("Cena", "Цена");
            dataGridViewOpcii.Columns.Add("isative", "В наличии");

        }
        private void ReadSingleRow(DataGridView dgwklient, IDataRecord record)
        {
            dgwklient.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetDecimal(3), record.GetString(4));
        }
        private void RefreshDataGrid(DataGridView dgwklient)
        {
            dgwklient.Rows.Clear();

            string queryString = $"select * from Opcii";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgwklient, reader);
            }
            reader.Close();
        }

        private void Opcii_Load(object sender, EventArgs e)
        {


            CreateColums();

            RefreshDataGrid(dataGridViewOpcii);

        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void базоваяКомплектацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bazovaya_Kom d = new Bazovaya_Kom(_user);
            this.Hide();
            d.ShowDialog();
        }

        private void комплектацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Komplektacia s = new Komplektacia(_user);
            this.Hide();
            s.ShowDialog();
        }

        private void оМоделиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Spravochnick_Model v = new Spravochnick_Model(_user);
            this.Hide();
            v.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }
    }
}
