﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    public partial class Form4 : Form
    {
        private SqlConnection sqlConnection = null;

        private SqlCommandBuilder sqlBuilder = null;

        private SqlDataAdapter sqlDataAdapter = null;

        private DataSet dataSet = null;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-HGGICHF\STP;Initial Catalog=avto;Integrated Security=True");
            sqlConnection.Open();
            LoadData();

        }
        private void LoadData()
        {

            sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Rabotnick", sqlConnection);
            sqlBuilder = new SqlCommandBuilder(sqlDataAdapter);

            sqlBuilder.GetInsertCommand();
            sqlBuilder.GetUpdateCommand();
            sqlBuilder.GetDeleteCommand();

            DataTable table = new DataTable();

            dataSet = new DataSet();

            sqlDataAdapter.Fill(dataSet, "Rabotnick");

            dataGridView1.DataSource = dataSet.Tables["Rabotnick"];

            dataGridView1.Columns[0].HeaderText = "ID Работник";
            dataGridView1.Columns[1].HeaderText = "Должность";
            dataGridView1.Columns[2].HeaderText = "Имя";
            dataGridView1.Columns[3].HeaderText = "Фамилия";
            dataGridView1.Columns[4].HeaderText = "Отчество";
            dataGridView1.Columns[5].HeaderText = "Телефон";
        }
        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 o = new Form2();
            o.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 o = new Form3();
            o.ShowDialog();
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            AboutBox1 aboba = new AboutBox1();
            aboba.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите добавить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                DataRow row = dataSet.Tables["Rabotnick"].NewRow();
                row["Dolshnost"] = textBox1.Text;
                row["Imya"] = textBox2.Text;
                row["Familiya"] = textBox3.Text;
                row["Otchestvo"] = textBox4.Text;
                row["Telefon"] = textBox5.Text;

                dataSet.Tables["Rabotnick"].Rows.Add(row);

                sqlDataAdapter.Update(dataSet, "Rabotnick");
                ReloadData();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }
        private void ReloadData()
        {
            try
            {
                dataSet.Tables["Rabotnick"].Clear();

                sqlDataAdapter.Fill(dataSet, "Rabotnick");

                dataGridView1.DataSource = dataSet.Tables["Rabotnick"];

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите удалить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                int rowIndex = dataGridView1.CurrentCell.RowIndex;

                dataSet.Tables["Rabotnick"].Rows[rowIndex].Delete();

                sqlDataAdapter.Update(dataSet, "Rabotnick");

                ReloadData();
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите отредактировать эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                int btbt = Convert.ToInt32(textBox5.Text);
                int rowIndex = dataGridView1.CurrentCell.RowIndex;
                dataSet.Tables["Rabotnick"].Rows[rowIndex]["Dolshnost"] = (textBox1.Text);
                dataSet.Tables["Rabotnick"].Rows[rowIndex]["Imya"] = (textBox2.Text);
                dataSet.Tables["Rabotnick"].Rows[rowIndex]["Familiya"] = (textBox3.Text);
                dataSet.Tables["Rabotnick"].Rows[rowIndex]["Otchestvo"] = (textBox4.Text);
                dataSet.Tables["Rabotnick"].Rows[rowIndex]["Telefon"] = (btbt);
                sqlDataAdapter.Update(dataSet, "Rabotnick");
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
 
            textBox1.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Dolshnost"].Value);
            textBox2.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Imya"].Value);
            textBox3.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Familiya"].Value);
            textBox4.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Otchestvo"].Value);
            textBox5.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Telefon"].Value);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ReloadData();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            //Книга.
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            //Таблица.
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
                }
            }
            //Вызываем нашу созданную эксельку.
            ExcelApp.Visible = true;
            ExcelApp.UserControl = true;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Familiya LIKE '%{textBox6.Text}%'";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 o = new Form5();
            o.ShowDialog();
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
