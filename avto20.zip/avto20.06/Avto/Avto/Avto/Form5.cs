﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    public partial class Form5 : Form
    {
        private SqlConnection sqlConnection = null;

        private SqlCommandBuilder sqlBuilder = null;

        private SqlDataAdapter sqlDataAdapter = null;

        private DataSet dataSet = null;
        public Form5()
        {
            InitializeComponent();
        }
      

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aAAAVVVVTTTOOOOO.Rabotnick". При необходимости она может быть перемещена или удалена.
            this.rabotnickTableAdapter.Fill(this.aAAAVVVVTTTOOOOO.Rabotnick);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aAAAVVVVTTTOOOOO.Klient". При необходимости она может быть перемещена или удалена.
            this.klientTableAdapter.Fill(this.aAAAVVVVTTTOOOOO.Klient);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aAAAVVVVTTTOOOOO.Avto". При необходимости она может быть перемещена или удалена.
            this.avtoTableAdapter.Fill(this.aAAAVVVVTTTOOOOO.Avto);

            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-HGGICHF\STP;Initial Catalog=avto;Integrated Security=True");
            sqlConnection.Open();
            LoadData();

        }

        private void button8_Click(object sender, EventArgs e)
        {
            ReloadData();
        }
        private void LoadData()
        {

            sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Dogovor", sqlConnection);
            sqlBuilder = new SqlCommandBuilder(sqlDataAdapter);

            sqlBuilder.GetInsertCommand();
            sqlBuilder.GetUpdateCommand();
            sqlBuilder.GetDeleteCommand();

            DataTable table = new DataTable();

            dataSet = new DataSet();

            sqlDataAdapter.Fill(dataSet, "Dogovor");

            dataGridView1.DataSource = dataSet.Tables["Dogovor"];

            dataGridView1.Columns[0].HeaderText = "ID Договор";
            dataGridView1.Columns[1].HeaderText = "ID Авто";
            dataGridView1.Columns[2].HeaderText = "ID Клиент";
            dataGridView1.Columns[3].HeaderText = "ID Работник";
            dataGridView1.Columns[4].HeaderText = "Дата заказа";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 o = new Form4();
            o.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 o = new Form3();
            o.ShowDialog();
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 o = new Form2();
            o.ShowDialog();
            this.Close();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void ReloadData()
        {
            try
            {
                dataSet.Tables["Dogovor"].Clear();

                sqlDataAdapter.Fill(dataSet, "Dogovor");

                dataGridView1.DataSource = dataSet.Tables["Dogovor"];

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            //Книга.
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            //Таблица.
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
                }
            }
            //Вызываем нашу созданную эксельку.
            ExcelApp.Visible = true;
            ExcelApp.UserControl = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AboutBox1 aboba = new AboutBox1();
            aboba.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;

            textBox1.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Data_Zakaza"].Value);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите добавить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {


                DataRow row = dataSet.Tables["Dogovor"].NewRow();

                row["ID_Avto"] = Convert.ToInt32(comboBox1.SelectedValue);
                row["ID_Klient"] = Convert.ToInt32(comboBox2.SelectedValue);
                row["ID_Rabotnick"] = Convert.ToInt32(comboBox3.SelectedValue);
                row["Data_Zakaza"] = (textBox1.Text);
                dataSet.Tables["Dogovor"].Rows.Add(row);

                sqlDataAdapter.Update(dataSet, "Dogovor");
                ReloadData();
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите удалить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                int rowIndex = dataGridView1.CurrentCell.RowIndex;

                dataSet.Tables["Dogovor"].Rows[rowIndex].Delete();

                sqlDataAdapter.Update(dataSet, "Dogovor");

                ReloadData();
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите отредактировать эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {


                int rowIndex = dataGridView1.CurrentCell.RowIndex;

                dataSet.Tables["Dogovor"].Rows[rowIndex]["ID_Avto"] = (comboBox1.SelectedValue);
                dataSet.Tables["Dogovor"].Rows[rowIndex]["ID_Klient"] = (comboBox2.SelectedValue);
                dataSet.Tables["Dogovor"].Rows[rowIndex]["ID_Rabotnick"] = (comboBox3.SelectedValue);
                dataSet.Tables["Dogovor"].Rows[rowIndex]["Data_Zakaza"] = (textBox1.Text);
                sqlDataAdapter.Update(dataSet, "Dogovor");
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
