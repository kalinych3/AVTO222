﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Avto
{
    public partial class Form2 : Form
    {
        private SqlConnection sqlConnection = null;

        private SqlCommandBuilder sqlBuilder = null;

        private SqlDataAdapter sqlDataAdapter = null;

        private DataSet dataSet = null;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-HGGICHF\STP;Initial Catalog=avto;Integrated Security=True");
            sqlConnection.Open();
            LoadData();
        }
        private void LoadData()
        {
            
            sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Avto", sqlConnection);
            sqlBuilder = new SqlCommandBuilder(sqlDataAdapter);
            
            sqlBuilder.GetInsertCommand();
            sqlBuilder.GetUpdateCommand();
            sqlBuilder.GetDeleteCommand();

            DataTable table = new DataTable();

            dataSet = new DataSet();

            sqlDataAdapter.Fill(dataSet, "Avto");

            dataGridView1.DataSource = dataSet.Tables["Avto"];

            dataGridView1.Columns[0].HeaderText = "ID Авто";
            dataGridView1.Columns[1].HeaderText = "Модель";
            dataGridView1.Columns[2].HeaderText = "Комплектация";
            dataGridView1.Columns[3].HeaderText = "Характеристика";
            dataGridView1.Columns[4].HeaderText = "Цвет";
            dataGridView1.Columns[5].HeaderText = "Цена";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;

            textBox1.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Model"].Value);
            textBox2.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Komplektacia"].Value);
            textBox3.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Xarakterictika"].Value);
            textBox4.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Cvet"].Value);
            textBox5.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Cena"].Value);

        }

        private void ReloadData()
        {
            try
            {
                dataSet.Tables["Avto"].Clear();

                sqlDataAdapter.Fill(dataSet, "Avto");

                dataGridView1.DataSource = dataSet.Tables["Avto"];

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {                    
            DialogResult result = MessageBox.Show("Вы действительно хотите удалить эту запись?","Сообщение",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1,MessageBoxOptions.DefaultDesktopOnly);

                if (result == DialogResult.Yes)
                { 
                int rowIndex = dataGridView1.CurrentCell.RowIndex;

                dataSet.Tables["Avto"].Rows[rowIndex].Delete();

                sqlDataAdapter.Update(dataSet, "Avto");

                ReloadData();
                }
                if(result == DialogResult.No)
                {
                this.Show();
                ReloadData();
                }
            }
           
        

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите отредактировать эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                int btbt = Convert.ToInt32(textBox5.Text);
                int rowIndex = dataGridView1.CurrentCell.RowIndex;
                dataSet.Tables["Avto"].Rows[rowIndex]["Model"] = (textBox1.Text);
                dataSet.Tables["Avto"].Rows[rowIndex]["Komplektacia"] = (textBox2.Text);
                dataSet.Tables["Avto"].Rows[rowIndex]["Xarakterictika"] = (textBox3.Text);
                dataSet.Tables["Avto"].Rows[rowIndex]["Cvet"] = (textBox4.Text);
                dataSet.Tables["Avto"].Rows[rowIndex]["Cena"] = (btbt);
                sqlDataAdapter.Update(dataSet, "Avto");
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите добавить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                DataRow row = dataSet.Tables["Avto"].NewRow();

                row["Model"] = textBox1.Text;
                row["Komplektacia"] = textBox2.Text;
                row["Xarakterictika"] = textBox3.Text;
                row["Cvet"] = textBox4.Text;
                row["Cena"] = textBox5.Text;

                dataSet.Tables["Avto"].Rows.Add(row);

                sqlDataAdapter.Update(dataSet, "Avto");
                ReloadData();

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Model LIKE '%{textBox6.Text}%'";

        }

        private void button4_Click(object sender, EventArgs e)
        {
            AboutBox1 aboba = new AboutBox1();
            aboba.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            //Книга.
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            //Таблица.
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
                }
            }
            //Вызываем нашу созданную эксельку.
            ExcelApp.Visible = true;
            ExcelApp.UserControl = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 o = new Form3();
            o.ShowDialog();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 o = new Form4();
            o.ShowDialog();
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ReloadData();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 o = new Form5();
            o.ShowDialog();
            this.Close();
        }
    }
}