﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    public partial class Form3 : Form
    {
        private SqlConnection sqlConnection = null;

        private SqlCommandBuilder sqlBuilder = null;

        private SqlDataAdapter sqlDataAdapter = null;

        private DataSet dataSet = null;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-HGGICHF\STP;Initial Catalog=avto;Integrated Security=True");
            sqlConnection.Open();
            LoadData();

        }
        private void LoadData()
        {

            sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Klient", sqlConnection);
            sqlBuilder = new SqlCommandBuilder(sqlDataAdapter);

            sqlBuilder.GetInsertCommand();
            sqlBuilder.GetUpdateCommand();
            sqlBuilder.GetDeleteCommand();

            DataTable table = new DataTable();

            dataSet = new DataSet();

            sqlDataAdapter.Fill(dataSet, "Klient");

            dataGridView1.DataSource = dataSet.Tables["Klient"];

            dataGridView1.Columns[0].HeaderText = "ID Клиента";
            dataGridView1.Columns[1].HeaderText = "Имя";
            dataGridView1.Columns[2].HeaderText = "Фамилия";
            dataGridView1.Columns[3].HeaderText = "Отчество";
            dataGridView1.Columns[4].HeaderText = "Телефон";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AboutBox1 aboba = new AboutBox1();
            aboba.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;

            textBox1.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Imya"].Value);
            textBox2.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Fmiliya"].Value);
            textBox3.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Otchestvo"].Value);
            textBox4.Text = Convert.ToString(dataGridView1.Rows[rowIndex].Cells["Telefon"].Value);
            
        }
        private void ReloadData()
        {
            try
            {
                dataSet.Tables["Klient"].Clear();

                sqlDataAdapter.Fill(dataSet, "Klient");

                dataGridView1.DataSource = dataSet.Tables["Klient"];

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите добавить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                DataRow row = dataSet.Tables["Klient"].NewRow();

                row["Imya"] = textBox1.Text;
                row["Fmiliya"] = textBox2.Text;
                row["Otchestvo"] = textBox3.Text;
                row["Telefon"] = textBox4.Text;

                dataSet.Tables["Klient"].Rows.Add(row);

                sqlDataAdapter.Update(dataSet, "Klient");
                ReloadData();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите удалить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            { 
                int rowIndex = dataGridView1.CurrentCell.RowIndex;

            dataSet.Tables["Klient"].Rows[rowIndex].Delete();

            sqlDataAdapter.Update(dataSet, "Klient");

            ReloadData();
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите отредактировать эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes)
            {
                int btbt = Convert.ToInt32(textBox4.Text);
                int rowIndex = dataGridView1.CurrentCell.RowIndex;
                dataSet.Tables["Klient"].Rows[rowIndex]["Imya"] = (textBox1.Text);
                dataSet.Tables["Klient"].Rows[rowIndex]["Fmiliya"] = (textBox2.Text);
                dataSet.Tables["Klient"].Rows[rowIndex]["Otchestvo"] = (textBox3.Text);
                dataSet.Tables["Klient"].Rows[rowIndex]["Telefon"] = (btbt);
                sqlDataAdapter.Update(dataSet, "Klient");
            }
            if (result == DialogResult.No)
            {
                this.Show();
                ReloadData();
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Fmiliya LIKE '%{textBox6.Text}%'";
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 o = new Form2();
            o.ShowDialog();
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 o = new Form4();
            o.ShowDialog();
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ReloadData();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            //Книга.
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            //Таблица.
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
                }
            }
            //Вызываем нашу созданную эксельку.
            ExcelApp.Visible = true;
            ExcelApp.UserControl = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 o = new Form5();
            o.ShowDialog();
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
