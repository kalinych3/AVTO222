﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Avto
{
    public partial class Bazovaya_Kom : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        private readonly User _user;
        public Bazovaya_Kom(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateColums()
        {
            dataGridViewKomBaza.Columns.Add("ID", "№");
            dataGridViewKomBaza.Columns.Add("ID_Komplektacia", "Комплектация");
            dataGridViewKomBaza.Columns.Add("ID_Filial", "Филиал");
            dataGridViewKomBaza.Columns.Add("Cena", "Цена");

        }

        private void ReadSingleRow(DataGridView dgwklient, IDataRecord record)
        {
            dgwklient.Rows.Add(record.GetInt32(0), record.GetInt32(1), record.GetInt32(2), record.GetDecimal(3));
        
        }
        private void базоваяКомплектацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Komplektacia n = new Komplektacia(_user);
            this.Hide();
            n.ShowDialog();
        }
        private void RefreshDataGrid(DataGridView dgwklient)
        {
            dgwklient.Rows.Clear();

            string queryString = $"select * from Bazovaya_Komplektacia";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgwklient, reader);
            }
            reader.Close();
        }
        private void Bazovaya_Kom_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridViewKomBaza);
        }

        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void опцииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Opcii u = new Opcii(_user);
            this.Hide();
            u.ShowDialog();
        }

        private void оМоделейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Spravochnick_Model u = new Spravochnick_Model(_user);
            this.Hide();
            u.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }
    }
}
