﻿namespace Avto
{
    partial class Dobavit_Rabotnicka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dobavit_Rabotnicka));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Registracia_button = new System.Windows.Forms.Button();
            this.back_button = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.Telefon_textBox = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.roleBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.Familiya_textBox = new System.Windows.Forms.TextBox();
            this.Parol = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Login = new System.Windows.Forms.TextBox();
            this.Otchestvo_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Imya_textBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.roleBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.roleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewDobavit = new System.Windows.Forms.DataGridView();
            this.roleBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.roleBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDobavit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(833, 83);
            this.panel1.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(380, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 37);
            this.label5.TabIndex = 39;
            this.label5.Text = "Добваить";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(364, -5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 42);
            this.label3.TabIndex = 38;
            this.label3.Text = "Авто";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(467, -5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 42);
            this.label4.TabIndex = 8;
            this.label4.Text = "Хит";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.Registracia_button);
            this.panel2.Controls.Add(this.back_button);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 542);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(833, 58);
            this.panel2.TabIndex = 7;
            // 
            // Registracia_button
            // 
            this.Registracia_button.BackColor = System.Drawing.Color.Teal;
            this.Registracia_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Registracia_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.Registracia_button.ForeColor = System.Drawing.Color.Black;
            this.Registracia_button.Location = new System.Drawing.Point(339, 21);
            this.Registracia_button.Name = "Registracia_button";
            this.Registracia_button.Size = new System.Drawing.Size(180, 37);
            this.Registracia_button.TabIndex = 10;
            this.Registracia_button.Text = "Добавить";
            this.Registracia_button.UseVisualStyleBackColor = false;
            this.Registracia_button.Click += new System.EventHandler(this.Registracia_button_Click);
            // 
            // back_button
            // 
            this.back_button.BackColor = System.Drawing.Color.Teal;
            this.back_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.back_button.ForeColor = System.Drawing.Color.Black;
            this.back_button.Location = new System.Drawing.Point(0, 21);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(111, 37);
            this.back_button.TabIndex = 10;
            this.back_button.Text = "<=Назад";
            this.back_button.UseVisualStyleBackColor = false;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Teal;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(710, 23);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(123, 37);
            this.button4.TabIndex = 9;
            this.button4.Text = "О программе";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 343);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(830, 202);
            this.panel3.TabIndex = 8;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(368, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(119, 31);
            this.label12.TabIndex = 41;
            this.label12.Text = "Запись:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.Telefon_textBox);
            this.panel4.Controls.Add(this.comboBox1);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.Familiya_textBox);
            this.panel4.Controls.Add(this.Parol);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.Login);
            this.panel4.Controls.Add(this.Otchestvo_textBox);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.Imya_textBox);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Location = new System.Drawing.Point(98, 34);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(648, 168);
            this.panel4.TabIndex = 42;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Teal;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(362, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 25);
            this.label11.TabIndex = 16;
            this.label11.Text = "Роль";
            // 
            // Telefon_textBox
            // 
            this.Telefon_textBox.Location = new System.Drawing.Point(135, 124);
            this.Telefon_textBox.Name = "Telefon_textBox";
            this.Telefon_textBox.Size = new System.Drawing.Size(116, 20);
            this.Telefon_textBox.TabIndex = 14;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(482, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(116, 21);
            this.comboBox1.TabIndex = 15;
            // 
            // roleBindingSource4
            // 
            this.roleBindingSource4.DataMember = "Role";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Teal;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(11, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Фамилия";
            // 
            // Familiya_textBox
            // 
            this.Familiya_textBox.Location = new System.Drawing.Point(135, 22);
            this.Familiya_textBox.Name = "Familiya_textBox";
            this.Familiya_textBox.Size = new System.Drawing.Size(116, 20);
            this.Familiya_textBox.TabIndex = 8;
            // 
            // Parol
            // 
            this.Parol.HideSelection = false;
            this.Parol.Location = new System.Drawing.Point(482, 83);
            this.Parol.Name = "Parol";
            this.Parol.Size = new System.Drawing.Size(116, 20);
            this.Parol.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Teal;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(13, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 25);
            this.label10.TabIndex = 13;
            this.label10.Text = "Телефон";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(362, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Пароль";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Teal;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(13, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 25);
            this.label8.TabIndex = 9;
            this.label8.Text = "Имя";
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(482, 52);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(116, 20);
            this.Login.TabIndex = 3;
            // 
            // Otchestvo_textBox
            // 
            this.Otchestvo_textBox.Location = new System.Drawing.Point(135, 83);
            this.Otchestvo_textBox.Name = "Otchestvo_textBox";
            this.Otchestvo_textBox.Size = new System.Drawing.Size(116, 20);
            this.Otchestvo_textBox.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(362, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Логин";
            // 
            // Imya_textBox
            // 
            this.Imya_textBox.Location = new System.Drawing.Point(135, 51);
            this.Imya_textBox.Name = "Imya_textBox";
            this.Imya_textBox.Size = new System.Drawing.Size(116, 20);
            this.Imya_textBox.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Teal;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(13, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 25);
            this.label9.TabIndex = 11;
            this.label9.Text = "Отчество";
            // 
            // roleBindingSource2
            // 
            this.roleBindingSource2.DataMember = "Role";
            // 
            // roleBindingSource
            // 
            this.roleBindingSource.DataMember = "Role";
            // 
            // dataGridViewDobavit
            // 
            this.dataGridViewDobavit.AllowUserToAddRows = false;
            this.dataGridViewDobavit.AllowUserToDeleteRows = false;
            this.dataGridViewDobavit.BackgroundColor = System.Drawing.Color.DimGray;
            this.dataGridViewDobavit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDobavit.Location = new System.Drawing.Point(-3, 77);
            this.dataGridViewDobavit.Name = "dataGridViewDobavit";
            this.dataGridViewDobavit.ReadOnly = true;
            this.dataGridViewDobavit.Size = new System.Drawing.Size(836, 269);
            this.dataGridViewDobavit.TabIndex = 9;
            // 
            // roleBindingSource1
            // 
            this.roleBindingSource1.DataMember = "Role";
            // 
            // roleBindingSource3
            // 
            this.roleBindingSource3.DataMember = "Role";
            // 
            // Dobavit_Rabotnicka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(833, 600);
            this.Controls.Add(this.dataGridViewDobavit);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Dobavit_Rabotnicka";
            this.Text = "Добавить\"AвтоХит\"";
            this.Load += new System.EventHandler(this.Registracia_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDobavit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Registracia_button;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Parol;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Login;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.TextBox Telefon_textBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Otchestvo_textBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Imya_textBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Familiya_textBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridViewDobavit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel4;
        private Avto22222222 avto22222222;
        private System.Windows.Forms.BindingSource roleBindingSource;
        private Avto22222222TableAdapters.RoleTableAdapter roleTableAdapter;
        private System.Windows.Forms.BindingSource roleBindingSource1;
        private Avto11111DataSet avto11111DataSet;
        private System.Windows.Forms.BindingSource roleBindingSource2;
        private Avto11111DataSetTableAdapters.RoleTableAdapter roleTableAdapter1;
       
        private System.Windows.Forms.BindingSource roleBindingSource3;
       
        private System.Windows.Forms.BindingSource roleBindingSource4;
        
    }
}