﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Avto
{
    public partial class Sklad : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        private readonly User _user;
        public Sklad(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateColums()
        {
            dataGridViewSklad.Columns.Add("ID", "№");
            dataGridViewSklad.Columns.Add("ID_Komplektacia", "Комплектация");
            dataGridViewSklad.Columns.Add("ID_Filial", "Филиал");
            dataGridViewSklad.Columns.Add("Kolichestvo", "Количество");
            dataGridViewSklad.Columns.Add("Aktivnost", "В наличии");

        }
        private void ReadSingleRow(DataGridView dgwSklad, IDataRecord record)
        {
            dgwSklad.Rows.Add(record.GetInt32(0), record.GetInt32(1), record.GetInt32(2), record.GetInt32(3), record.GetString(4));
        }
        private void RefreshDataGrid(DataGridView dgwSklad)
        {
            dgwSklad.Rows.Clear();

            string queryString = $"select * from Sklad";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgwSklad, reader);
            }
            reader.Close();
        }
        private void search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Sklad where concat (ID, Kolichestvo, ID_Komplektacia,ID_Filial, Aktivnost) like '%" + search_textBox.Text + "%'";
            SqlCommand com = new SqlCommand(searchString, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Sklad_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridViewSklad);

        }
        private void deleteRow()
        {
            int index = dataGridViewSklad.CurrentCell.RowIndex;
            dataGridViewSklad.Rows[index].Visible = false;
            if (dataGridViewSklad.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {

                dataGridViewSklad.Rows[index].Cells[3].Value = RowState.Deleted;
                return;
            }
            dataGridViewSklad.Rows[index].Cells[3].Value = RowState.Deleted;
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void search_textBox_TextChanged(object sender, EventArgs e)
        {
            search(dataGridViewSklad);
            СlearFields();
        }
        private void СlearFields()
        {
            ID_textBox.Text = " ";
            Kom_comboBox.Text = " ";
            Filial_comboBox.Text = " ";
            Kol_textBox.Text = " ";

        }
        private void edit()
        {
            var selectedRowIndex = dataGridViewSklad.CurrentCell.RowIndex;

            var id = ID_textBox.Text;
            var Kom = Kom_comboBox.Text;
            var filial = Filial_comboBox.Text;
            int Kol;


            if (dataGridViewSklad.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            {
                if (int.TryParse(Kol_textBox.Text, out Kol))
                {
                    dataGridViewSklad.Rows[selectedRowIndex].SetValues(id, Kom, filial,Kol );

                }
                else
                {
                    MessageBox.Show("Количество должен иметь числовой формат!");
                }

            }
        }

        private void delete_button_Click(object sender, EventArgs e)
        {
            deleteRow();
            Update();
            RefreshDataGrid(dataGridViewSklad);
            СlearFields();
        }

        private void edit_button_Click(object sender, EventArgs e)
        {
            edit();
            Update();
            RefreshDataGrid(dataGridViewSklad);
            СlearFields();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            СlearFields();
            Update();
        }

        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }
    }
}
