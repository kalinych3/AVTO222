﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Avto
{
    public class User
    {
        public string Login { get; set; }

        public bool IsAdmin { get;}
        public bool IsMenedger { get;}

        public string StatusAd => IsAdmin ? "Админ" : "Сотрудник";

        public string StatusMe => IsMenedger ? "Менеджер":"Сотрудник";
        public User(string Login, bool isAdmin,bool menedger)
        {
            Login = Login.Trim();

            IsAdmin = isAdmin;
            IsMenedger = menedger;
        
        }

    }
}
