﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Claims;
using System.Drawing.Printing;

namespace Avto
{
    public partial class Rabotnick_Form : Form
    {
        DataBase dataBase = new DataBase();
        private readonly User _user;
        int selectedRow;
        public Rabotnick_Form(User user)
        {
            
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            _user = user;
        }

        private void Admin()
        {
            Registracia_button.Enabled = _user.IsAdmin;


        }
        private void CreateColums()//создание колонок
        {
            dataGridViewRabotnick.Columns.Add("ID", "№");
            dataGridViewRabotnick.Columns.Add("Familiya", "Фамилия");
            dataGridViewRabotnick.Columns.Add("Imya", "Имя");
            dataGridViewRabotnick.Columns.Add("Otchestvo", "Отчество");
            dataGridViewRabotnick.Columns.Add("Telefon", "Телефон");
            dataGridViewRabotnick.Columns.Add("ID_Role", "Роль");

        }
        private void ReadSingleRow(DataGridView dgwRabotnick, IDataRecord record)
        {
            dgwRabotnick.Rows.Add(record.GetInt32(0),  record.GetString(1), record.GetString(2), record.GetString(3), record.GetInt32(4),record.GetString(5));
        }
        private void RefreshDataGrid(DataGridView dgwRabotnick)//обновление
        {
            dgwRabotnick.Rows.Clear();

            string queryString = $"select Rabotnick.ID, Rabotnick.Familiya, Rabotnick.Imya,Rabotnick.Otchestvo, Rabotnick.Telefon, Role.Nazvanie from Rabotnick, Role where Rabotnick.ID = Role.ID"; 
            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection()); 

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgwRabotnick, reader);
            }


            reader.Close();
        }
        private void Form4_Load(object sender, EventArgs e)
        {
         

            Admin();
            
            CreateColums();
            RefreshDataGrid(dataGridViewRabotnick);
        }

        //private void search(DataGridView dgwRabotnick)//поиск
        //{
        //    dgwRabotnick.Rows.Clear();
        //    string searchString = $"select * from Rabotnick where concat (ID, ID_Role, Familiya, Imya, Otchestvo,Telefon ) like '%" + search_textBox.Text + "%'";
        //    SqlCommand com = new SqlCommand(searchString, dataBase.getConnection());
        //    dataBase.openConnection();
        //    SqlDataReader reader = com.ExecuteReader();
        //    while (reader.Read())
        //    {
        //        ReadSingleRow(dgwRabotnick, reader);
        //    }
        //    reader.Close();
        //}

        private void deleteRow()//удалить
        {
            int index = dataGridViewRabotnick.CurrentCell.RowIndex;
            dataGridViewRabotnick.Rows[index].Visible = false;
            if (dataGridViewRabotnick.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {

                dataGridViewRabotnick.Rows[index].Cells[3].Value = RowState.Deleted;
                return;
            }
            dataGridViewRabotnick.Rows[index].Cells[3].Value = RowState.Deleted;
        }
        private void Update()//сохранение
        {
            dataBase.openConnection();
            for (int index = 0; index < dataGridViewRabotnick.Rows.Count; index++)
            {
                var rowState = (RowState)dataGridViewRabotnick.Rows[index].Cells[3].Value;

                if (rowState == RowState.Existed)
                    continue;

                if (rowState == RowState.Deleted)
                {
                    var id = Convert.ToInt32(dataGridViewRabotnick.Rows[index].Cells[0].Value);
                    var deleteQuery = $"delete from Rabotnick where ID = {id}";
                    var command = new SqlCommand(deleteQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
                if (rowState == RowState.Modifiled)
                {
                    var ID = dataGridViewRabotnick.Rows[index].Cells[0].Value.ToString();
                    var Familiya = dataGridViewRabotnick.Rows[index].Cells[1].Value.ToString();
                    var Imya = dataGridViewRabotnick.Rows[index].Cells[2].Value.ToString();
                    var Otchestvo = dataGridViewRabotnick.Rows[index].Cells[3].Value.ToString();
                    var telefon = dataGridViewRabotnick.Rows[index].Cells[4].Value.ToString();
                    var ID_Role = dataGridViewRabotnick.Rows[index].Cells[5].Value.ToString();
                    

                    var changeQuery = $"update Rabotnick,Role set ID_Role = '{ID_Role}', Familiya = '{Familiya}', Imya = '{Imya}','{Otchestvo}', Telefon = '{telefon}' where  ID = '{ID}'";

                    var command = new SqlCommand(changeQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
            }
            dataBase.closeConnection();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();
            aboba.ShowDialog();
        }

       
       

       
        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }

     

       
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        //private string result = "";


        //private void print_button_Click(object sender, EventArgs e)
        //{
        //    Text = "1";
        //    result = "Строка 1\n\n";
 
        //    result += "Строка 2\nСтрока 3";
            
        //    PrintDocument printDocument = new PrintDocument();

        //    printDocument.PrintPage += PrintPageHandler;

        //    PrintDialog printDialog = new PrintDialog();

        //    printDialog.Document = printDocument;

        //    if (printDialog.ShowDialog() == DialogResult.OK)
        //        printDialog.Document.Print();
        //}

        //private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        //{

        //}
       
        // void PrintPageHandler(object sender, PrintPageEventArgs e)
        // {
        //    e.Graphics.DrawString(result, new Font("Arial", 14), Brushes.Black, 0, 0);
        // }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void edit()//изменение
        {
            var selectedRowIndex = dataGridViewRabotnick.CurrentCell.RowIndex;

            var id = ID_textBox.Text;

            var Role = Role_comboBox.Text;
            var Familiya = Familiya_textBox.Text;
            var Imya = Imya_textBox.Text;
            var Otchestvo = Otchestvo_textBox.Text;

            int telefon;


            if (dataGridViewRabotnick.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            {
                if (int.TryParse(Telefon_textBox.Text, out telefon))
                {
                    dataGridViewRabotnick.Rows[selectedRowIndex].SetValues(id, Role, Familiya, Imya, telefon, Otchestvo);
                }
                else
                {
                    MessageBox.Show("Телефон должен иметь числовой формат!");
                }

            }
        }
        private void СlearFields()
        {
            ID_textBox.Text = " ";
            Role_comboBox.Text = " ";
            Familiya_textBox.Text = " ";
            Imya_textBox.Text = " ";
            Otchestvo_textBox.Text= " ";
            Telefon_textBox.Text = " ";

        }
        private void dataGridViewRabotnick_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewRabotnick.Rows[selectedRow];

                ID_textBox.Text = row.Cells[0].Value.ToString();
                Familiya_textBox.Text = row.Cells[1].Value.ToString();
                Imya_textBox.Text = row.Cells[2].Value.ToString();
                Otchestvo_textBox.Text= row.Cells[3].Value.ToString();
                Telefon_textBox.Text = row.Cells[4].Value.ToString();
                Role_comboBox.Text = row.Cells[5].Value.ToString();
            }
        }

        

        private void delete_button_Click(object sender, EventArgs e)
        {
            deleteRow();
            Update();
            //RefreshDataGrid(dataGridViewRabotnick);
            СlearFields();
        }

        private void update_button_Click(object sender, EventArgs e)
        {

            //RefreshDataGrid(dataGridViewRabotnick);
            СlearFields();
        }

        private void save_button_Click(object sender, EventArgs e)
        {
            Update();
            СlearFields();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            СlearFields();
            Update();
        }

        private void edit_button_Click(object sender, EventArgs e)
        {
            edit();
            Update();
            //RefreshDataGrid(dataGridViewRabotnick);
            СlearFields();

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void Imya_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void search_textBox_TextChanged(object sender, EventArgs e)
        {
            //search(dataGridViewRabotnick);
        }

        private void Role_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Registracia_button_Click(object sender, EventArgs e)
        {
            Dobavit_Rabotnicka Registracia = new Dobavit_Rabotnicka(_user);
            
            Registracia.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }
    }
}
