﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Avto
{
    public partial class Rabotnick_Dobavit : Form
    {
        DataBase dataBase = new DataBase();
        public Rabotnick_Dobavit()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Rabotnick_Dobavit_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "avto11111DataSet.Role". При необходимости она может быть перемещена или удалена.
            this.roleTableAdapter.Fill(this.avto11111DataSet.Role);

        }

        private void add_button_Click(object sender, EventArgs e)
        {
            dataBase.openConnection();
            if (Familiya_textBox.Text == String.Empty || Imya_textBox.Text == String.Empty || Otchestvo_textBox.Text == String.Empty || Telefon_textBox.Text == String.Empty || Role_comboBox.Text == string.Empty)
            {
                MessageBox.Show("Пустые поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var Familiya = Familiya_textBox.Text;
            var Imya = Imya_textBox.Text;
            var Otchestvo = Otchestvo_textBox.Text;
            var Role = Role_comboBox.SelectedValue;

            int Telefon;

            if (int.TryParse(Telefon_textBox.Text, out Telefon))
            {
                var querystring = $"insert into  Rabotnick (Familiya, Imya, Otchestvo ,Telefon, ID_Role) values ('{Familiya}', '{Imya}', '{Otchestvo}','{Telefon}','{Role}') ";
                var command = new SqlCommand(querystring, dataBase.getConnection());
                command.ExecuteNonQuery();
                DialogResult result = MessageBox.Show("Вы действительно хотите добавить эту запись?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            }
            else
            {
                MessageBox.Show("Запись не удалось создать!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            dataBase.closeConnection();
        }

        private void Role_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
