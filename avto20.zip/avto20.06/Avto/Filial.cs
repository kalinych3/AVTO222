﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    
    public partial class Filial : Form
    {
        DataBase dataBase = new DataBase();

        int selectedRow;
        private readonly User _user;
        public Filial(User user)
        {
            _user=user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void CreateColums()
        {
            dataGridViewFilial.Columns.Add("ID", "№");
            dataGridViewFilial.Columns.Add("Gorod", "Город");
            dataGridViewFilial.Columns.Add("Ulicya", "Улица");
            dataGridViewFilial.Columns.Add("Dom", "Дом");
            dataGridViewFilial.Columns.Add("Telefon", "Телефон");
            

        }
        private void ReadSingleRow(DataGridView dataGridViewFilial, IDataRecord record)
        {
            dataGridViewFilial.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetInt32(4));
        }
        private void RefreshDataGrid(DataGridView dataGridViewFilial)
        {
            dataGridViewFilial.Rows.Clear();

            string queryString = $"select * from Filial";

            SqlCommand command = new SqlCommand(queryString, dataBase.getConnection());

            dataBase.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dataGridViewFilial, reader);
            }
            reader.Close();
        }
        private void Felial_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridViewFilial);

        }
        
       

        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }

      

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewFilial.Rows[selectedRow];

                ID_textBox.Text = row.Cells[0].Value.ToString();
                Gorod_textBox.Text = row.Cells[1].Value.ToString();
                Ulicya_textBox.Text = row.Cells[2].Value.ToString();
                Dom_textBox.Text = row.Cells[3].Value.ToString();
                Telefon_textBox.Text = row.Cells[4].Value.ToString();
            }
        }

        private void search(DataGridView dataGridViewFilial)
        {
            dataGridViewFilial.Rows.Clear();
            string searchString = $"select * from Filial where concat (ID, Gorod, Ulicya, Dom, Telefon ) like '%" + search_textBox.Text + "%'";
            SqlCommand com = new SqlCommand(searchString, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dataGridViewFilial, reader);
            }
            reader.Close();
        }

        private void deleteRow()
        {
            int index = dataGridViewFilial.CurrentCell.RowIndex;
            dataGridViewFilial.Rows[index].Visible = false;
            if (dataGridViewFilial.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {

                dataGridViewFilial.Rows[index].Cells[4].Value = RowState.Deleted;
                return;
            }
            dataGridViewFilial.Rows[index].Cells[4].Value = RowState.Deleted;
        }
        private void Update()
        {
            dataBase.openConnection();
            for (int index = 0; index < dataGridViewFilial.Rows.Count; index++)
            {
                var rowState = (RowState)dataGridViewFilial.Rows[index].Cells[4].Value;

                if (rowState == RowState.Existed)
                    continue;

                if (rowState == RowState.Deleted)
                {
                    var id = Convert.ToInt32(dataGridViewFilial.Rows[index].Cells[0].Value);
                    var deleteQuery = $"delete from Filial where ID = {id}";
                    var command = new SqlCommand(deleteQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
                if (rowState == RowState.Modifiled)
                {
                    var ID = dataGridViewFilial.Rows[index].Cells[0].Value.ToString();
                    var Gorod = dataGridViewFilial.Rows[index].Cells[1].Value.ToString();
                    var Ulicya = dataGridViewFilial.Rows[index].Cells[2].Value.ToString();
                    var Dom  = dataGridViewFilial.Rows[index].Cells[3].Value.ToString();
                    var telefon = dataGridViewFilial.Rows[index].Cells[4].Value.ToString();

                    var changeQuery = $"update Filial set Gorod = '{Gorod}', Ulicya = '{Ulicya}', Dom = '{Dom}', Telefon = '{telefon}' where  ID = '{ID}'";

                    var command = new SqlCommand(changeQuery, dataBase.getConnection());
                    command.ExecuteNonQuery();
                }
            }
            dataBase.closeConnection();
        }

        private void edit()
        {
            var selectedRowIndex = dataGridViewFilial.CurrentCell.RowIndex;

            var id = ID_textBox.Text;

            var Gorod = Gorod_textBox.Text;
            var Ulicya = Ulicya_textBox.Text;
            var Dom = Dom_textBox.Text;
            
            int telefon;


            if (dataGridViewFilial.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            {
                if (int.TryParse(Telefon_textBox.Text, out telefon))
                {
                    dataGridViewFilial.Rows[selectedRowIndex].SetValues(id, Gorod, Ulicya,Dom, telefon);
                   
                }
                else
                {
                    MessageBox.Show("Цена должна иметь числовой формат!");
                }

            }
        }

        private void СlearFields()
        {
            ID_textBox.Text = " ";
            Gorod_textBox.Text = " ";
            Ulicya_textBox.Text = " ";
            Dom_textBox.Text = " ";
            Telefon_textBox.Text = " ";

        }

        private void add_button_Click(object sender, EventArgs e)
        {
           
        }

        private void update_button_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewFilial);
            СlearFields();
        }

        private void delete_button_Click(object sender, EventArgs e)
        {
            deleteRow();
            СlearFields();
        }

        private void edit_button_Click(object sender, EventArgs e)
        {
            edit();
            СlearFields();
        }

        private void search_textBox_TextChanged(object sender, EventArgs e)
        {
            search(dataGridViewFilial);
            СlearFields();
        }

        private void save_button_Click(object sender, EventArgs e)
        {
            Update();
            СlearFields();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            СlearFields();
        }

        private void менюToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(_user);
            this.Hide();
            menu.ShowDialog();
        }

        private void Registracia_button_Click(object sender, EventArgs e)
        {
         
            
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            O_program aboba = new O_program();

            aboba.ShowDialog();
        }
    }

}


