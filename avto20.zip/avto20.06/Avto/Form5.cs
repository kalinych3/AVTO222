﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Avto
{
    public partial class Form5 : Form
    {
        DataBase dataBase = new DataBase();
        private readonly User _user;
        int selectedRow;

        public Form5(User user)
        {
            _user = user;
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void CreateColums()
        {
            dataGridView_Dogovor.Columns.Add("ID", "№");
            dataGridView_Dogovor.Columns.Add("Familiya", "Фамилия");
            dataGridView_Dogovor.Columns.Add("Imya", "Имя");
            dataGridView_Dogovor.Columns.Add("Dom", "Отчество");
            dataGridView_Dogovor.Columns.Add("Telefon", "Телефон");
            dataGridView_Dogovor.Columns.Add("Pasport", "Паспорт");


        }

        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetInt32(3));
        }
        private void Form5_Load(object sender, EventArgs e)
        {
          
            
           


        }

        private void button8_Click(object sender, EventArgs e)
        {
           
        }
      

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

      
        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
       

        private void button5_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            //Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            //Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            ////Книга.
            //ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);
            ////Таблица.
            //ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dataGridView1.ColumnCount; j++)
            //    {
            //        ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;
            //    }
            //}
            ////Вызываем нашу созданную эксельку.
            //ExcelApp.Visible = true;
            //ExcelApp.UserControl = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AboutBox1 aboba = new AboutBox1();
            aboba.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
